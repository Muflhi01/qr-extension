# qr-extension
QR extension for Slurp
